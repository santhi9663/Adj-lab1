package Hashtable;

public class Hashtable {
	package arraylist;
	import java.util.*; 
	public class hashtable {
		 public static void main(String args[]){  
			  Hashtable<Integer,String> hm=new Hashtable<Integer,String>();  
			  
			  hm.put(1201,"santhi");  
			  hm.put(1202,"sri");  
			  hm.put(1203,"shivani");  
			  hm.put(1204,"jaya");  
			  
			  for(Map.Entry m:hm.entrySet()){  
			   System.out.println(m.getKey()+" "+m.getValue());  
			  }  
			 
}
