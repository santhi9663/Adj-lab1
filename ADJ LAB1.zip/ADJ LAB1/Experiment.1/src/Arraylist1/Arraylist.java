package arraylist;
import java.util.*;
public class Arraylist {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
				 ArrayList<String> list=new ArrayList<String>();//Creating arraylist    
				     list.add("Mango");//Adding object in arraylist    
				     list.add("Apple");    
				     list.add("Banana");    
				     list.add("Grapes");    
				     //Printing the arraylist object   
				     System.out.println(list);  
				}
}
