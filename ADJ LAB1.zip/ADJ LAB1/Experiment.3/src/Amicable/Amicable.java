package Amicable;
import java.rmi.*;
public class Amicable {
public interface Amicable extends Remote {
//declaring abstract method
public String amicable(int a,int b) throws RemoteException;
 

}
